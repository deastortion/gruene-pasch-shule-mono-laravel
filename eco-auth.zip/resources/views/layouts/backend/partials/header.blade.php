<header class="header" id="header">
    <div class="header__toggle">
        <span class='las la-bars' id="header-toggle"></span>
    </div>
    <div class="header__img">
        <img src="{{ asset('assets/img/profile.jpg') }}" alt="">
    </div>
</header>