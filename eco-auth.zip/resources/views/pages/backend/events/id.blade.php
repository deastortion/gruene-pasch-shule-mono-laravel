@extends('layouts.backend.index')


@section('unique-styles')

@endsection

@section('content')
    {{-- {{$event}} --}}
    {!! $event->content !!}
@endsection
