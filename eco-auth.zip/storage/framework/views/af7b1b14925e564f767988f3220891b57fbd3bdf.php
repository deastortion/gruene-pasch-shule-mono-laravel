

<?php $__env->startSection('unique-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card__body">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus maxime, quam facilis voluptatum fuga
            doloribus adipisci labore aliquam sed delectus quod ex? Iusto placeat excepturi dolore repudiandae nam
            recusandae ab?
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/dashboard/home.blade.php ENDPATH**/ ?>