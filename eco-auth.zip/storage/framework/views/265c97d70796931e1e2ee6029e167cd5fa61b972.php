<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans:wght@400;700&family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="/assets/css/main.css">

    <?php echo $__env->yieldContent('page-styles'); ?>
</head>

<body>
    <div class="wrapper">
        <main class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>

</html><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/layouts/auth.blade.php ENDPATH**/ ?>