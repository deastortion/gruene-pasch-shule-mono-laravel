

<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/dashboard/events/index.blade.php ENDPATH**/ ?>