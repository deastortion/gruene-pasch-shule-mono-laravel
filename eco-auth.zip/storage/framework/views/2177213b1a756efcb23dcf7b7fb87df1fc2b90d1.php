<footer class="footer">
    <div class="container">
        <div class="footer__row">
            <div class="footer__text">
                <p>
                    Every resource belongs to official owners <span>Grüne Schule</span> and <span>School
                        §204</span>
                </p>
                <p>
                    @deastortion  2021
                </p>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/layouts/frontend/partials/footer.blade.php ENDPATH**/ ?>