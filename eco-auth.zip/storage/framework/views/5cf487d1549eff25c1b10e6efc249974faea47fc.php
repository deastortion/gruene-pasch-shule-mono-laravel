 

<?php $__env->startSection('page-styles'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="create-event">
        <div class="container">
            <div class="create-event__row">
                asd
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/events/create.blade.php ENDPATH**/ ?>