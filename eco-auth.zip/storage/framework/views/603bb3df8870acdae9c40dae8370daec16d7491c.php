<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php echo $__env->yieldContent('seo'); ?>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans:wght@400;700&family=Open+Sans:wght@300;400;600;700;800&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="/assets/css/main.css">

    <?php echo $__env->yieldContent('page-styles'); ?>
</head>

<body>
    <div class="wrapper">
        <?php echo $__env->make('layouts.default.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('layouts.default.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <script src="/assets/js/script.js"></script>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/layouts/default/index.blade.php ENDPATH**/ ?>