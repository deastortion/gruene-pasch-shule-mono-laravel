<header class="header">
    <div class="container">
        <div class="header__row">
            <div class="header__logo">
                <a href="/">
                    Grüne Schule
                </a>
            </div>
            <div class="header__burger">
                <span>
                </span>
            </div>
            <nav class="header__nav">
                <ul class="header__links">
                    <li class="header__link <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                        <a href="/">
                            Home
                        </a>
                    </li>
                    <li class="header__link <?php echo e(request()->is('events') ? 'active' : ''); ?>">
                        <a href="/events">
                            Events
                        </a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                        <li class="header__link">
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                Logout
                            </a>
                        </li>
                        <form action="<?php echo e(route('logout')); ?>" id="logout-form" method="POST" style="display: none">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php else: ?>
                        <li class="header__link">
                            <a href="/login">
                                Login
                            </a>
                        </li>
                        <li class="header__link">
                            <a href="/register">
                                Register
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/layouts/default/partials/header.blade.php ENDPATH**/ ?>