

<?php $__env->startSection('unique-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/backend/content/stats.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cards">
        <?php if($usersCount): ?>
            <div class="card">
                <div class="card__info">
                    <h2 class="card__number">
                        <?php echo e($usersCount); ?>

                    </h2>
                    <small class="card__name">
                        Users
                    </small>
                </div>
                <div class="card__icon">
                    <span class="las la-users"></span>
                </div>
            </div>
        <?php endif; ?>
        <?php if($eventsCount): ?>
            <div class="card">
                <div class="card__info">
                    <h2 class="card__number">
                        <?php echo e($eventsCount); ?>

                    </h2>
                    <small class="card__name">
                        Events
                    </small>
                </div>
                <div class="card__icon">
                    <span class="las la-clipboard-list"></span>
                </div>
            </div>
        <?php endif; ?>
        <?php if($eventsCount): ?>
            <div class="card">
                <div class="card__info">
                    <h2 class="card__number">
                        <?php echo e($eventsCount); ?>

                    </h2>
                    <small class="card__name">
                        Events
                    </small>
                </div>
                <div class="card__icon">
                    <span class="las la-clipboard-list"></span>
                </div>
            </div>
        <?php endif; ?>
        <?php if($eventsCount): ?>
            <div class="card">
                <div class="card__info">
                    <h2 class="card__number">
                        <?php echo e($eventsCount); ?>

                    </h2>
                    <small class="card__name">
                        Events
                    </small>
                </div>
                <div class="card__icon">
                    <span class="las la-clipboard-list"></span>
                </div>
            </div>
        <?php endif; ?>



    </div>

    <div class="recent">
        <div class="card-events">
            <div class="card__header">
                <h4 class="card__title">Latest events</h4>
                <a href="/dashboard/events" class="card__link">View all</a>
            </div>
            <div class="card__body">
                <?php if(count($events)): ?>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="event">
                            <div class="event__image">
                                
                                <img src="<?php echo e($event->image); ?>" alt="">
                            </div>
                            <div class="event__body">
                                <div class="event__name">
                                    <?php echo e($event->title); ?>

                                </div>
                                <div class="event__description">
                                    <?php echo e($event->description); ?>

                                    Lorem ipsum dolor sit amet.
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-events">
            <div class="card__header">
                <h4 class="card__title">New users</h4>
                <a href="/dashboard/events" class="card__link">View all</a>
            </div>
            <div class="card__body">

                <?php if(count($users)): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="user">
                            <div class="user__image">
                                <img src="/assets/img/profile.jpg" alt="">
                            </div>
                            <div class="user__body">
                                <div class="user__name">
                                    <?php echo e($user->name); ?>

                                </div>
                                <div class="event__description">
                                    <p>Email: <?php echo e($user->email); ?></p>
                                    <p>Registered: <?php echo e($user->created_at->format('Y/m/d H:i:s')); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/pages/backend/home.blade.php ENDPATH**/ ?>