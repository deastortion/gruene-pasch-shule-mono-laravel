

<?php $__env->startSection('unique-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/backend/content/users/show.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card__header">
            <div class="user__image">
                <img src="/assets/img/profile.jpg" alt="">
            </div>
            <div class="user__info">
                <?php echo e($user->name); ?>

            </div>
        </div>
        <div class="card__body">
            <div class="user__info">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur dicta, soluta pariatur reiciendis
                totam, ipsa maiores nihil officia cupiditate dignissimos saepe recusandae, repudiandae aliquam! Autem porro
                voluptatibus non obcaecati eos?
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/pages/backend/users/show.blade.php ENDPATH**/ ?>