

<?php $__env->startSection('unique-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/backend/content/users/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form id="delete" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
        <div class="card">
            <div class="card__header">
                <h1 class="card__title">
                    Users
                </h1>
                <div class="info">
                    
                    <span id="selected">Selected: 0</span>
                    <span>Total: <?php echo e($users->total()); ?></span>
                    <span>From 1 to <?php echo e($users->lastPage()); ?></span>
                    <span>Per page: <?php echo e($users->perPage()); ?></span>
                    <span>Current page: <?php echo e($users->currentPage()); ?></span>
                </div>
                <div class="actions">
                    <a href="#" class="action" onclick="sendRequest()">Delete</a>
                </div>
            </div>
            <div class="card__body">
                <table>
                    <thead>
                        <tr>
                            <th class="header-selected"><input type="checkbox" name="checkbox-all" id="checkbox-all"></th>
                            <th class="header-id">Id</th>
                            <th class="header-name">Name</th>
                            <th class="header-email">Email</th>
                            <th class="header-date">Date of registration</th>
                            <th class="header-status">Status</th>
                            <th class="header-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($users)): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><input class="checkbox" type="checkbox" name="checkbox-<?php echo e($user->id); ?>"
                                            id="checkbox-<?php echo e($user->id); ?>" value="<?php echo e($user->id); ?>"></td>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->created_at ? $user->created_at->format('d.m.Y H:i:s') : 'Empty'); ?></td>
                                    <td>Active</td>
                                    <td class="td-actions">
                                        <a href="<?php echo e('/dashboard/users/'. $user->id); ?>" class="btn">View</a>
                                        <a class="btn">Edit</a>
                                        <a class="btn">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="pagination__wrapper">
            <?php echo e($users->links()); ?>


        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/pages/backend/users/index.blade.php ENDPATH**/ ?>