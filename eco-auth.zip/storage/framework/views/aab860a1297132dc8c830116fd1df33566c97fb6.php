<header class="header" id="header">
    <div class="header__toggle">
        <span class='las la-bars' id="header-toggle"></span>
    </div>
    <div class="header__img">
        <img src="<?php echo e(asset('assets/img/profile.jpg')); ?>" alt="">
    </div>
</header><?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/layouts/backend/partials/header.blade.php ENDPATH**/ ?>