<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
    
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/backend/main.css')); ?>">
    <?php echo $__env->yieldContent('unique-styles'); ?>
</head>

<body id="body-pd">

    
    <?php echo $__env->make('layouts.backend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('layouts.backend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    
    <main class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>




    
    <script src="<?php echo e(asset('assets/js/admin.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/layouts/backend/index.blade.php ENDPATH**/ ?>