<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans:wght@400;700&family=Open+Sans:wght@300;400;600;700;800&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin/dashboard.css')); ?>">
</head>

<body>
    <script src="https://kit.fontawesome.com/a6d763d44b.js" crossorigin="anonymous"></script>

    <div class="wrapper">
        <aside class="sidebar">
            <h2 class="sidebar__title">
                Sidebar
            </h2>
            <nav class="sidebar__nav">
                <ul>
                    <li><a href="#"><i class="fas fa-home"></i>Home</a></li>
                    <li><a href="#"><i class="far fa-calendar-alt"></i>Events</a></li>
                    <li><a href="#"><i class="fas fa-users"></i>Users</a></li>
                    <li><a href="#"><i class="fas fa-cogs"></i>Settingss</a></li>
                    <li><a href="#"><i class="fas fa-sign-out-alt"></i>Log out</a></li>
                </ul>
            </nav>
        </aside>
        <main class="content">
            <div class="home">
                <h1 class="home__title">
                    Hey, this is your admin panel
                </h1>
                <p class="home__text">
                    Here is gonna be some descriptions
                </p>
            </div>
        </main>
    </div>


</body>

</html>
<?php /**PATH D:\OpenServer\domains\eco-auth\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>