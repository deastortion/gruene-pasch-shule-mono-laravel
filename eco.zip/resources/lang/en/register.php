<?php

return [
    'title' => 'Registration',
    'name' => 'Name ...',
    'email' => 'Email address ...',
    'password' => 'Password ...',
    'password-confirm' => 'Password confirm ...',
    'redirect-to-home' => 'Get back to <a href="/">home page</a>',
    'button' => 'Let\'s go',
];