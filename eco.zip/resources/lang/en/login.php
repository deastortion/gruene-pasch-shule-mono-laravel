<?php

return [
    'title' => 'Login',
    'email' => 'Email ...',
    'password' => 'Password ...',
    'redirect-to-home' => 'Get back to <a href="/">home page</a>',
    'button' => 'Let\'s go',
];