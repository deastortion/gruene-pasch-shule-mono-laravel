<?php


return [
    'navigation_links' => [
        'home' => 'Home',
        'events' => 'Events',
        'login' => 'Login',
        'register' => 'Register',
        'logout' => 'Logout',
        'dashboard' => 'Dashboard',
        'profile' => 'Profile'
    ],
];