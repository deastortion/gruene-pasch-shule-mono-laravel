<?php

return [
    'title' => 'Hey, this is a project called <span>Grüne Schule</span>',
    'description' => 'Do you want to get closer to nature protection? Then check this project out!',
    'button' => 'Okay, let\'s go',
];
