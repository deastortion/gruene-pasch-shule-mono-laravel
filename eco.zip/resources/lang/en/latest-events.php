<?php 

return [
    'title' => 'Latest events',
    'subtitle' => 'Do you want to get to know us better? Check out our events',
    'button' => 'Take a look!'
];