<?php 

return [
    'resources-notification' => 'Every resource belongs to official owners <span>Grüne Schule</span> and <span>School №112</span>',

];