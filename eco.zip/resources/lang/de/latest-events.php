<?php 

return [
    'title' => 'Aktuelle Ereignisse',
    'subtitle' => 'Wollen Sie uns besser kennenlernen? Schauen Sie sich unsere Veranstaltungen an',
    'button' => 'Schauen Sie mal rein!'
];