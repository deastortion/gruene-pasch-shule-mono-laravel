<?php

return [
    'title' => 'Anmelden',
    'email' => 'E-Mail ...',
    'password' => 'Passwort ...',
    'redirect-to-home' => '<a href="/">Zurück zur Startseite</a>',
    
    'button' => 'Los geht\'s',
];