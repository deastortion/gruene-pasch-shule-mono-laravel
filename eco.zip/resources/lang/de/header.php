<?php


return [
    'navigation_links' => [
        'home' => 'Startseite',
        'events' => 'Ereignisse',
        'login' => 'Anmelden',
        'register' => 'Registrierung',
        'logout' => 'Abmelden',
        'dashboard' => 'Dashboard',
    ],
];