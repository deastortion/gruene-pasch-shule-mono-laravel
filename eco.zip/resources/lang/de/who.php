<?php 

return [
    'title' => 'Wer sind wir?',
    'description' => 'Wir sind ein neues Projekt, das auf Initiative des Goethe-Instituts Usbekistan und der Schule Nr. 112 ins Leben gerufen wurde. Unser Hauptziel ist es, die Idee des Naturschutzes in Usbekistan und in anderen Flugzeugen zu fördern.',
    'button' => 'Nächste',
];