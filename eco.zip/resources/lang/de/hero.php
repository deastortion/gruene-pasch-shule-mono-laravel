<?php 

return [
    'title' => 'Hey, das ist ein Projekt <span>Grüne Schule</span>',
    'description' => 'Möchten Sie dem Naturschutz näher kommen? Dann schau dir dieses Projekt an!',
    'button' => 'Okay, los geht\'s',
];