<?php

return [
    'title' => 'Registrierung',
    'name' => 'Name ...',
    'email' => 'E-Mail...',
    'password' => 'Passwort ...',
    'password-confirm' => 'Passwort-Bestätigung ...',
    'redirect-to-home' => '<a href="/">Zurück zur Startseite</a>',
    'button' => 'Los geht\'s',
];