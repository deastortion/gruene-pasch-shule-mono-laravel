<?php 

return [
    'resources-notification' => 'Alle Ressourcen gehören den offiziellen Eigentümern <span>Grüne Schule</span> und <span>Schule №112</span>',

];