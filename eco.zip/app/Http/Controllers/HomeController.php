<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;




class HomeController extends Controller
{
    public function index()
    {
        $events = Cache::remember('latest-events', 3, function () {
            return Event::latest()->take(3)->get();
        });
        return view('pages.frontend.home', ['events' => $events]);
    }



    public function redirectAfterLogin()
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        if (Auth::user()->is_admin) {
            return redirect('/dashboard');
        }

        return redirect('/');
    }


    public function changeLanguage(Request $request)
    {
        App::setLocale($request->lang);
        session()->put('locale', $request->lang);

        return redirect()->back();
    }
}
