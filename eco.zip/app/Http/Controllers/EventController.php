<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $search = $request->search;
        $perPage = 6;

        if (!empty($search)) {
            $events = Event::where('title', 'LIKE', '%' . $search . '%')
                ->orWhere('description', 'LIKE', '%' . $search . '%')
                ->paginate($perPage)
                ->onEachside(1);
        } else {
            $events = Event::latest()->paginate($perPage, ['id', 'title', 'description', 'image', 'created_at'])
                ->onEachSide(1);
        }

        return view('pages.frontend.events.index', ['events' => $events]);
    }
    // 
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event)
    {
        return view('pages.frontend.events.show', ['event' => $event]);
    }
}
